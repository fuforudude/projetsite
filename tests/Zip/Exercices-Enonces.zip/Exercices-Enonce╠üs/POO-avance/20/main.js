/*
Créer une classe Des:
Attribut : nombre de face
Fonction : lancer : retourne un nombre aléatoire entre 1 et le nombre de face
Créer une classe Godet :
Attributs : contient N dés, chaque dé à son nombre propre de faces
Fonction : lancer : somme des lancers des N dés 
*/