let tableau = new Array(
  'fonctionnels'
  ,'performance'
  ,'personnalisation'
  ,'publicité'
);

// Créer une liste avec les éléments du tableau
// installer un gestionnaire d'évènement pour onclick, pour onmouseover et pour onmouseout
// Comportement attendu : 
//    lorsque la souris passe par dessus un item de la liste, il prend la couleur tomato si et seulement si il n'est pas sélectionné
//    lorsque la souris n'est plus sur un item de la liste, il reprend la couleur par défaut si et seulement si il n'est pas sélectionné
//    lorsqu'on click sur un élément non sélectionné, il devient sélectionné
//    lorsqu'on click sur un élément sélectionné, il devient non sélectionné
//    un élément sélectionné est affiché de couleur yellowGreen

