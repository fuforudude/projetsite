// Ecrire "les B1 A </h2>" dans le flux de sortie
