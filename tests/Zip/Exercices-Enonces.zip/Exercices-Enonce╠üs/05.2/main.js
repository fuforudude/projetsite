// Afficher les tables de multiplication de 1 à 10 à l'aide d'une boucle while
