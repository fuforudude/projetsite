// Ecrire une fonction qui ajoute un noeud texte "Bonjour tout le monde" dans le noeud div d'id 'cible'
function creerBonjour(){
  // Créé un noeud texte
  const textHTML = // TODO
  // retourne le noeud texte
  return textHTML;
}

// Appeler la fonction qui créé le noeud texte
const noeudTexte = creerBonjour(); // noeudTexte contient le noeud texte créé

// Récupérer le noeud 'div' d'id "cible" à partir du document :
const cible = // TODO
// Rajouter le noeud texte comme enfant du noeud 'cible' de notre document :
cible.appendChild(noeudTexte);

