let tableau = new Array(
  {prenom : "Pablo" , nom : "Picasso"},
  {prenom : "Lucian" , nom : "Freud"},
  {prenom : "Marc" , nom : "Chagall"},
  {prenom : "Paul" , nom : "Klee"},
  {prenom : "Wassily" , nom : "Kandinsky"},
  {prenom : "Francis" , nom : "Picabia"},
  {prenom : "Pierre" , nom : "Soulages"},
  {prenom : "Maurice" , nom : "Denis"},
  {prenom : "Henri" , nom : "Matisse"},
  {prenom : "Francis" , nom : "Bacon"},
  {prenom : "Edgar" , nom : "Degas"},
  {prenom : "René" , nom : "Magritte"}
);

// Ecrire une ou des fonctions pour créer une liste HTML d'élements Nom Prénom avec l'API DOM
// Le nom du peintre est écrit en gras et en noir, le prénom du peintre est écrit en italique et en rouge
// utiliser les classes référencées par le fichier css