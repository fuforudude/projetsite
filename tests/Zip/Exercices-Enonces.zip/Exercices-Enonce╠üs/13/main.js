// Jeu de carte
// Un jeu de carte ce sont 4 couleurs {cœur, carreau, trèfle, pique} et 13 valeurs {2,3,4,5,6,7,8,9,10, valet, dame, roi, as}
const Couleurs = {cœur:1, carreau: 2, trèfle:3, pique:4};
const NBR_COULEURS = Object.keys(Couleurs).length ;
const Valeurs = // compléter !
const NBR_VALEURS = // compléter !

// Définir un tableau qui contient un jeu de carte. Chaque cellule du tableau permet de retrouver la couleur et la valeur de la carte qu’elle contient
// Définir une fonction constructeur pour la classe :
function carte( couleur_, valeur_){

}
// Création du jeu :
let jeu = new Array();
function creerJeu(){
}

// Ecrire une fonction qui prend en paramètre un tableau de jeu de cartes et l’écrit en table HTML sur 4 lignes et 13 colonnes
function creer_carte_html(carte){
}

// afficher le jeu de carte
function afficher_jeu(jeu_cartes){
}

function update_affichage(){
  afficher_jeu(jeu);
}
// Ecrire une fonction qui prend un tableau de jeu de cartes en paramètre et le mélange : on coupe le tas en deux et on reforme un tas en alternant les cartes de chaque moitié
function lancer_de(max){
  const r = Math.random() ;
  const u = r * max + 1 ;
  return Math.floor(u) ;
}

function melanger_jeu(jeu_cartes)
{
}

// Ecrire une fonction prend deux paramètres en entrée : un tableau de jeu de cartes et un entier N. Elle mélange le jeu de carte N fois
function repeter_melange(jeu_cartes, N){
}
// Avec ces différentes fonctions, construire la page suivante : une première table avec les cartes dans l’ordre de couleurs et de valeurs tels qu’indiqué au début de l’exercice et une seconde table avec les cartes après un nombre de mélange aléatoire (nombre aléatoire entre 25 et 50)
creerJeu();
update_affichage();

function melanger_cartes(){
}

