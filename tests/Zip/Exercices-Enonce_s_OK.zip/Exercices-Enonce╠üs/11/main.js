// Vérfier qu'un mot est un palindrome
function est_palindrome(mot){  
}

// Vérifier que si les saisis sont des palindromes
function verifierPalindrome(){
  const mot_input = document.querySelector("#motPalindrome") ;
  const mot_a_verifier = mot_input.value ;
  let message = "'" + mot_a_verifier + "' ";
  if(est_palindrome(mot_a_verifier)){
      message +=  "est" ;
  }
  else{
      message +=  "n'est pas" ;
  }
  message +=  " un palindrome" ;
  alert(message) ;
}