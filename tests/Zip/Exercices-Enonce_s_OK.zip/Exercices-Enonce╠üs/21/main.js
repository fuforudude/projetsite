/*
Créer une classe CompétencePrimaire avec les propriétés suivantes:
nom
valeur_courante
valeur_max
bonus
fonction : valeur_actualisee :  retourne la valeur courante augmentée du bonus
*/

/*
Créer une classe CompétenceDérivée qui dérive de CompétencePrimaire avec les propriétés suivantes:
coef (coefficient d’ajustement sur la valeur)
Mettre à jour la fonction valeur_actualisée : retourne la valeur courante multipliée par le coefficient et augmentée du bonus
*/