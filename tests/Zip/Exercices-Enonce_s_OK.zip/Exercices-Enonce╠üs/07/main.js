//Afficher la liste suivante dans l’orde alphabétique :
// Lucian Freud, Marc Chagall, Paul Klee, Wassily Kandinsky , Francis Picabia, Pierre Soulages, Maurice Denis, Henri Matisse, Francis Bacon, Edgar Degas, René Magritte,
// Créer un tableau avec la liste précédente

// Trier le tableau (https://fr.wikipedia.org/wiki/Tri_%C3%A0_bulles) par prénom

// Afficher le tableau trié
