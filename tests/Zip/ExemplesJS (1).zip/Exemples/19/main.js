function add(l,r)
{
  return l+r ;
}
function bis(v){
  return v+2;
}

let ajouter_2 = function(v) { return add(v,2) ;};

document.write(ajouter_2(3));


// ajouter<n>(12) => 12 + n 
function make_ajouter_n(n)
{
  let ajouter_n = function(v) { return v + n ;} ;
  return ajouter_n;
}

let ajout_2 = make_ajouter_n(2) ;
let ajouter_3 = make_ajouter_n(3) ;
let ajouter_23 = make_ajouter_n(23) ;

ajout_2(23) === 25 ;
ajouter_3(23) === 26 ;
ajouter_23(23) === 46 ;


let f = i => document.write(i) ;
let f2 = function(i){ document.write(i);} ;

