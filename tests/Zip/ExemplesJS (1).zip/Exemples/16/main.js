
function ouvrirBalise(elt){
  document.write('<'+elt+'>') ; 
}
function fermerBalise(elt){
  document.write('</'+elt+'>') ; 
}

/* function ajouterItemListe(item){
  ouvrirBalise('li') ;
  document.write(item) ;
  fermerBalise('li') ;
} */

function creerListeHTML(tableau){
  ouvrirBalise('ol');
  tableau.forEach( item => {
     ouvrirBalise('li') ;
     document.write(item) ;
     fermerBalise('li') ;
  }) ;
  fermerBalise('ol') ;
}

const tableau = ['un','deux','trois','quatre','cinq','six','sept'];
creerListeHTML(tableau) ;

let t = [0,2,4,6,8,10];
t.forEach(i => document.write(i + '<br>') );

let tableau2 = [
  {prenom : "Pablo" , nom : "Picasso"},
  {prenom : "Lucian" , nom : "Freud"},
  {prenom : "Marc" , nom : "Chagall"},
  {prenom : "Paul" , nom : "Klee"},
];

document.write('<br>');

const prenoms = tableau2.map( p => p.prenom) ;
prenoms.forEach( v => document.write(v + '<br>') );

document.write('<br>');

// on enchaine les deux étapes
tableau2.map( p => p.nom).forEach( v => document.write(v +'<br>') ); 