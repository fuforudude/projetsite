// On récupère l'élément sur lequel on veut détecter le clic
const elt = document.getElementById('mon-lien');    
const elt_body = document.getElementsByTagName('body')[0];    

elt_body.addEventListener('click', (evt) => {  
    elt_body.innerText = "C'est cliqué dans le body, le clic s'est propagé, au feu !";
});

// On écoute l'événement click et on change le contenu de notre élément pour afficher "C'est cliqué !"
elt.addEventListener('click', (evt) => {  
    evt.preventDefault();  // empêche le comportement par défaut   
    evt.stopPropagation(); // empêche la propagation vers son parent
    elt.innerText = "C'est cliqué sur le lien !";
});