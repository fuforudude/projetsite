function recurse(node){
  let str = ('<li>') ;
  str += (node.nodeName + ' : ' + node.constructor.name +'"');
  if(node.attributes){
    for(let i = 0; i<node.attributes.length;++i){
      attr = node.getAttributeNode(node.attributes[i].name) ;
      str += '("' + node.attributes[i].name + '" = "' + attr.value + '" : ' + attr.constructor.name + ')' ;
    }
  }
  if (node.childNodes.length>0) {
    str += ('<ul>');
    str += Array.from(node.childNodes).reduce((acc, n) => acc + recurse(n),'');
    str += ('</ul>');
  }
  str += ('</li>');
  return str
}

response = recurse(document) ;
document.write(response);
