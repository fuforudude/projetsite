// String API
let v = 'Bonjour papay' ; 
document.write(typeof v);  document.write('<br/>');
document.write(v.length); document.write('<br/>');
document.write(v[1]); document.write('<br/>');
document.write(v.indexOf('jou'));document.write('<br>');
document.write(v.slice(2,5));document.write('<br>');
document.write(v.toLowerCase());document.write('<br>');
document.write(v.toUpperCase());document.write('<br>');
document.write(v.replace('Bon', 'Beau'));document.write('<br>');
document.write(v.concat(' tout le monde'));document.write('<br>');
document.write (v === 'Bonjour');document.write('<br>');
v = 'zéro;un;deux;trois;quatre;cinq;six;sept;huit;neuf;dix';
let tab_str = v.split(';') ;
document.write(tab_str); document.write('<br>');
document.write(tab_str[3]); document.write('<br>');

let a = 5;
let b = "5";
if (a==b) {
    console.log("a egal b avec ==");
}
else {
    console.log("a different de b avec ==");
}

if (a===b) {
    console.log("a egal b avec ===");
}
else {
    console.log("a different de b avec ===");
}
