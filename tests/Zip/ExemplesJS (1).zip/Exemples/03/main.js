var variable = 42 ;
document.write(variable) ;
document.write('<br>') ;
variable = "Bonjour";
document.write(variable) ;
document.write('<br>') ;
variable = 3.14;
document.write(variable) ;
document.write('<br>') ;
variable = [1,2,3,4];
document.write(variable) ;
document.write('<br>') ;

variable = {
    titre : "La chute" ,
    auteur : "Albert CAMUS"
};
document.write(variable) ;
document.write('<br>') ;
document.write(variable.titre + " : " + variable.auteur) ;
document.write('<br>') ;
