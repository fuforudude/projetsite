async function calcul1() {
    // attendre 4s
    // await new Promise(r => setTimeout(r, 4000));
    return 3*2;
}
  
async function calcul2() {
    // attendre 5s
    //await new Promise(r => setTimeout(r, 5000));
    return 4**4;
}
  
async function calcul() {
    return await calcul1() + await calcul2();
}
  
calcul()
    .then(res => {
      document.getElementById("resultat")
              .innerText = "Le résultat du calcul : "+res;
});