// fetch
// tester également avec https://jsonplaceholder.typicode.com/
// et voir https://www.youtube.com/watch?v=z9pcgJX1DdY
// syntaxe avec then()
function request_normale() {
    fetch('https://thronesapi.com/api/v2/Characters')
      .then(response => response.json())
      //.then(response => response.text())
      .then(json => console.log(json))
      .catch( err => {
        console.log("erreur : "+err)
        })
}
// syntaxe avec async/await : plus récent et state of the art
async function request_async() {
    let response = await fetch('https://thronesapi.com/api/v2/Characters');
    let json = await response.json();
    console.log(json);
}
request_normale();
//request_async();
