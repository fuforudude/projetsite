function calcul() {
    return 4**4;
}

Promise.all([300*2, calcul()])
    // ... = spread operator : permet de remplacer le tableau par les valeurs qu'il contient
    .then(results => Math.max(...results))
    .then(max => {
        document.getElementById("resultat")
        .innerText = "Le max est : "+max;
    });