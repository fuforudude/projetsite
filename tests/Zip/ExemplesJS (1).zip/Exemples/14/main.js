
let p_picasso = {
    prenom : 'Pablo' ,
    nom : 'Picasso' ,
    style_de_peinture : 'cubisme'
};

let prenom_id = "prenom";

document.write(p_picasso.nom + ' ' +  '<br/>' ) ;

let s_dali = {
    prenom : 'Salvador' ,
    nom : 'Dali' ,
    style_de_peinture : 'surealisme'
};

document.write(s_dali['nom'] + ' ' + s_dali['prenom'] + '<br>' ) ; 

let peintre = {
    'prenom' : 'Henri' ,
    'nom' : 'Matisse',
    style_de_peinture : 'Fauvisme'
} ;

document.write(peintre['nom'] + ' ' + peintre['prenom'] + ', ' + peintre.style_de_peinture + '<br>' ) ; 
document.write(peintre['nom'] + ' ' + peintre['prenom'] + ', ' + peintre['style_de_peinture'] + '<br>' ) ; 

// exemples sur les if/else
let a = 5
let c = '5'

if (a != c) {
    document.write("Ils sont différents au sens souple")
}

if (a !== c) {
    document.write("Ils sont différents au sens strict")
}

if (a > 4 && a < 6) {
    console.log("a == 5");
}
else {
    console.log("a != 5");
}

let b = (a%2 == 0)?56:45 ;
document.write("<br/>");
document.write(b);