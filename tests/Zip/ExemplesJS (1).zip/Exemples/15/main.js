// avec let il y a un parcours :
// of : par valeurs
// in : par indices

let t = [10,11,12,13,14,15];
for(let v of t){
   document.write(v) ;
   document.write(' ');
}
document.write('<br>') ;

for(let v in t){
  document.write(v+" :" +t[v]) ;
  document.write(' ');
}
document.write('<br>') ;

let s = 'bonjour';
for(let c of s){
  document.write(c.toUpperCase()) ;
}
document.write('<br>') ;

let p = {
  nom : 'Miro',
  prenom : 'Joan'
};

for(let attr in p){
  document.write( attr + ' : ' + p[attr] + '<br>') ;
}

// pas le droit de parcourir un objet par valeurs
for(let attr of p){
  document.write( attr +'<br>') ;
}

const skip = 3;
const stop = 8;
let i = 0;
while (i<10) {
   if (i === skip) {
      i++;
      continue;
   }
   if (i === stop) {
     break;
   }
   i++;
   document.write("coucou "+i+" <br/>");
}

let v = ["b","o","n","j","o","u","r"];

// foreach fonctionnel
v.forEach(element => {
  if (element === "o" || (element === "u")) {
    document.write("*");
  }
  else  {
    document.write(element);
  }
});

document.write("<br/>et ... <br/>");

for (let i=0; i <10; i++ ) {
  document.write(i);
}