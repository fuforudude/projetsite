//let t = [3, 5, 8];
let t = new Array(5,7,78)
document.write(t.toString());
document.write("<br/>");

t.push(67); // ajout à la fin
document.write(t.toString());
document.write("<br/>");
document.write(t[3]);
document.write("<br/>");

document.write(t.length);
document.write("<br/>");

document.write(t.pop()); // enlève le dernier élément et retourne l'élément enlevé
document.write("<br/>");
document.write(t.toString());

document.write("<br/>");

document.write(t.length);
document.write("<br/>");

document.write(t.shift()); // enlève le premier élément
document.write("<br/>");
document.write(t.unshift(2)); // ajout au début
document.write("<br/>");
document.write(t);
document.write("<br/>");
document.write(t.splice(1, 1, 12)); // ajoute ou enleve des éléments
document.write("<br/>");
document.write(t);
