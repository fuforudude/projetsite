let cible = document.querySelector("#cible") ;
let clic = document.querySelector("#clic") ;
let data;

clic.onclick = () => {
    for (let c of data) {
        const item = document.createElement("li") ;
        item.setAttribute("id","item_"+c.firstName) ;
        const texte = document.createTextNode(c.lastName) ;
        item.appendChild(texte) ;
        cible.appendChild(item) ;
    }
}

function display(value) {
    for (let c of value) {
        document.write(c.name+" <br/>");
    }
}

fetch("https://thronesapi.com/api/v2/Characters")
  .then(res => { if (res.ok) return res.json(); })
  //.then(value => display(value) )
  .then(value => data = value )
  .catch(err => document.write("Une erreur est survenue"));