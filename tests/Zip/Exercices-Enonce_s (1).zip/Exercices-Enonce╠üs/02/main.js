let v = 42 ;
// afficher dans la console le type de v

v = 3.14  ;
// afficher dans la console le type de v

v = "chaine";
// afficher dans la console le type de v

v = true;
// afficher dans la console le type de v

v = {prop : "valeur" };
// afficher dans la console le type de v

v = [4,5,6]
// afficher dans la console le type de v
