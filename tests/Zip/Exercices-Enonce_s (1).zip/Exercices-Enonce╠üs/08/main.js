// Ecrire une fonction lancer_de qui prend un nombre en paramètre
// et retourne un entier aléatoire entre 1 et le paramètre

// Appeler la fonction et afficher le résultat
