let v = 'bonjour' ; 
// Dans la chaine v, afficher le caractère * à la place des voyelles
// en utilisant une boucle while et l'instruction switch/case
