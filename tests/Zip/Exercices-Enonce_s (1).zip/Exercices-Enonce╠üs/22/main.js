// Gestion d’un club
/*
Classe ‘Personne’
propriétés : nom + prénom + date naissance
méthodes : affichage, age
*/

/*
Classe ‘Membre’ : est-un Personne ET 
propriétés : numéro de membre + cotisationAJour + Date d’adhésion
méthodes : est_a_jour_cotisation, anciennete
*/

/*
Classe Dirigeant : est-un Membre ET 
propriétés : titre
méthodes : afficher_titre
*/


/*
Classe Animateur : est-un Personne
propriété : date embauche, salaire
méthode : anciennete
*/


// Exemple :
const a1 = new Animateur('Jean','Machin',new Date(1990,11,25),1500) ;
a1.afficher();
document.write('Ancienneté : ' + a1.anciennete()+'<br>');
const d1 = new Dirigeant('Jean-Michel','Bigboss', new Date(1953,5,15), "Président") ;
d1.paye_cotisation();
d1.afficher();
document.write('Cotisation à payer : ' + (d1.cotisationAttendue?"Oui":"Non")+'<br>');