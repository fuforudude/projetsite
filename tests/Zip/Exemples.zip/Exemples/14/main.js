
let p_picasso = {
    prenom : 'Pablo' ,
    nom : 'Picasso' ,
    style_de_peinture : 'cubisme',
    annee_naissance : 1881
};

let prenom_id = "prenom";

document.write(p_picasso.nom + ' ' +  '<br/>' ) ;

let s_dali = {
    prenom : 'Salvador' ,
    nom : 'Dali' ,
    style_de_peinture : 'surealisme',
    annee_naissance : 1904
};

document.write(s_dali['nom'] + ' ' + s_dali['prenom'] + '<br>' ) ; 

let h_matisse = {
    'prenom' : 'Henri' ,
    'nom' : 'Matisse',
    style_de_peinture : 'Fauvisme',
    annee_naissance : 1869
} ;

h_matisse.nom = "MATISSE"

let mes_peintres = [p_picasso, h_matisse, s_dali]

for (let p of mes_peintres) {
    document.write("=> " + p.nom + ' ' + p.prenom + ', ' + p.style_de_peinture + '<br>' ) ; 
}

document.write(h_matisse['nom'] + ' ' + h_matisse['prenom'] + ', ' + h_matisse.style_de_peinture + '<br>' ) ; 
document.write(mes_peintres[0].nom + ' ' + mes_peintres[0].prenom + ', ' + mes_peintres[0].style_de_peinture + '<br>' ) ; 

class Voiture {
    constructor(numero, vitesse_max) {
        this.numero = numero;
        this.vitesse_max = vitesse_max;
      }
    accelerer() {
        this.vitesse = this.vitesse + 10;
    }
    klaxonner() {
        document.write("pouet");
    }
}

voiture_joe = new Voiture("14EF23", 150)
voiture_joe.accelerer();
voiture_max = new Voiture("23ER345", 200)
