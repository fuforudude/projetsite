let age_du_capitaine = 42 ;
age_du_capitaine = age_du_capitaine + 1 ;
document.write(age_du_capitaine) ;

document.write('<br/>') ;
age_du_capitaine = "34";
document.write(age_du_capitaine) ;
document.write('<br/>') ;
age_du_capitaine = 3.14;
document.write(age_du_capitaine) ;
document.write('<br/>') ;
age_du_capitaine = [11,22,33,44];
document.write(age_du_capitaine) ;
document.write('<br/>') ;

let mon_livre_la_chute = {
    titre : "La chute" ,
    auteur : "Albert CAMUS",
    nb_pages : 350,
    editeur : "gallimard",
    date_parution : "20/01/1956"
};

let ma_belle_dodoche = {
    modele : "2CV",
    marque : "citroen"
}

mon_livre_la_chute.nb_pages = 400;

document.write(mon_livre_la_chute) ;
document.write('<br/>') ;
document.write(mon_livre_la_chute["titre"] + " : " + mon_livre_la_chute.auteur+ " : " + mon_livre_la_chute.nb_pages) ;
document.write('<br/>') ;
