let age_bebe = 2;
console.log(age_bebe);
console.log(typeof age_bebe);

age_bebe = 2.5;
console.log(typeof age_bebe);

age_bebe="2.3";
console.log(typeof age_bebe);

age_bebe=true;
console.log(typeof age_bebe);

console.log(typeof { vrai : true , faux : false})

console.log(typeof [3,4,5])

/*
let v = 6;
const est_pair = (v%2 == 0)?true:false;
console.log(est_pair)

// équivalent de l'écriture ci-dessus mais en bcp plus long !
let w = 7;
let est_pair2;
if (w%2 == 0) {
    est_pair2 = true;
}
else {
    est_pair2 = false;
}

if (v) {
    console.log("v existe");
}

for (let i =10; i >0; i=i-2 ) {
    console.log(i);
}

document.write(Math.abs(-5))
*/

// triple égalité = égalité stricte

console.log(1 === 1);
// expected output: true

console.log('hello' === 'hello');
// expected output: true

console.log('1' ===  1);
// expected output: false

console.log(0 === false);
// expected output: false

// double égalité = égalité non stricte : il se "débrouille"

console.log(1 == 1);
// expected output: true

console.log('hello' == 'hello');
// expected output: true

console.log('1' ==  1);
// expected output: true

console.log(0 == false);
// expected output: true

