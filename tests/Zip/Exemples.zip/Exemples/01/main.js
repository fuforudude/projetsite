// ceci est une fonction qui affiche l'heure
function horloge() {
    let aujourdhui = new Date();
    document.getElementById('heure').innerHTML = aujourdhui.toLocaleTimeString() ;
    window.setTimeout(horloge, 1000); // rappel de la fonction dans 1 seconde 
}

/* appel de ma fonction
c'est bien beau ce commentaire
sur 3 lignes */
horloge();

