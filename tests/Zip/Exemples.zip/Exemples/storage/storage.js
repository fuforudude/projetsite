const personne = {"nom":"Braque","prenom":"Georges"};
sessionStorage.setItem("pers", JSON.stringify(personne));
const p = sessionStorage.getItem("pers");
document.write(p);
sessionStorage.removeItem("pers");
sessionStorage.clear();

document.write("<br/>");

localStorage.setItem("pers", JSON.stringify(personne));
const p2 = localStorage.getItem("pers");
document.write(p2);
localStorage.removeItem("pers");
localStorage.clear();