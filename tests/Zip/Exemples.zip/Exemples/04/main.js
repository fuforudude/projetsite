const a = 42 ;
document.write(a) ;
document.write('<br>') ;
a = "Bonjour";
document.write(a) ;
document.write('<br>') ;
a = 3.14;
document.write(a) ;
document.write('<br>') ;
a = [1,2,3,4];
document.write(a) ;
document.write('<br>') ;

a = {titre : "La chute" , auteur : "Albert CAMUS"};
document.write(a) ;
document.write('<br>') ;
document.write(a.titre + " : " + a.auteur) ;
document.write('<br>') ;
