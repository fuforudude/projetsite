function addition(a,b) {
    return a+b;
}
function max(a,b) {
    if (a>b) {
        return a;
    }
    else {
        return b;
    }
}

console.log(addition(4,5));
console.log(addition(4,3));
console.log(max(4,35));
console.log(max(44,35));