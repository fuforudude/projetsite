function plus(l,r) {
    return l+r;
}
    
document.write(plus(2,3) === 15);
document.write("<br/>")
document.write(Math.ceil(3.7))