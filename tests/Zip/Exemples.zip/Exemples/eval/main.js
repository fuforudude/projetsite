let tableau = [
    {prenom : "Pablo" , nom : "Picasso"},
    {prenom : "Lucian" , nom : "Freud"},
    {prenom : "Marc" , nom : "Chagall"}
    ];

let mon_code = "const prenoms = tableau.map( p => p.nom) ;prenoms.forEach( i=> document.write(i + '<br>') ); " ;

eval(mon_code);