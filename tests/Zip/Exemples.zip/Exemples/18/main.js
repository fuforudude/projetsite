function ajouterItemListe(nom){
  const item = document.createElement("li") ;

  item.setAttribute("id","item_"+nom) ;

  const texte = document.createTextNode(nom) ;
  item.appendChild(texte) ;
  return item ;
}

function creerListe (noms){
  const ul = document.createElement("ul")
  noms.forEach( num => {
    const item = ajouterItemListe(num) ;
    ul.appendChild(item) ;
  });
  return ul;
}

let cible = document.querySelector("#cible") ;
cible.style.color = 'red';
let liste = creerListe(["un","deux","trois","quatre","cinq","vingt sept", "vingt huit"]) ;

//let trois = liste.querySelector("#item_deux") ;
//liste.removeChild(trois) ;

cible.appendChild(liste) ;
