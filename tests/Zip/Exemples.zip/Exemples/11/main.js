function test() {
  var var_var = "var_var";
  let let_var = "let_var";

  document.write(var_var); document.write('<br/>');
  document.write(let_var); document.write('<br/>');
  document.write(age); document.write('<br/>');

  {
     var var_var_scoped = "var_var_scoped";
     let let_var_scoped = "let_var_scoped";
     document.write(var_var_scoped); document.write('<br/>');
     document.write(let_var_scoped); document.write('<br/>');
     document.write(age); document.write('<br/>');
  }

  document.write(var_var_scoped); document.write('<br/>');
  document.write(let_var_scoped); document.write('<br/>');
}

let age = 20;
document.write(age); document.write('<br/>');

test();