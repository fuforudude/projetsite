// fetch
// tester également avec https://jsonplaceholder.typicode.com/
// et voir https://www.youtube.com/watch?v=z9pcgJX1DdY
// syntaxe avec then()
function request_then() {
    fetch('https://thronesapi.com/api/v2/Characters')
      .then(response => response.json())
      //.then(response => response.text())
      .then(json => console.log(json))
      .catch( err => {
        console.log("erreur : "+err)
        })
}

// syntaxe avec async/await : plus récent et state of the art
async function request_async() {
    let response = await fetch('https://thronesapi.com/api/v2/Characters');
    let json = await response.json();
    console.log(json);
}
//request_then();
request_async();

// test clash royal
async function request_async_clash() {
  let response = await fetch('https://api.clashroyale.com/v1/cards', {
    method: 'GET',
    headers: { Authorization : "Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiIsImtpZCI6IjI4YTMxOGY3LTAwMDAtYTFlYi03ZmExLTJjNzQzM2M2Y2NhNSJ9.eyJpc3MiOiJzdXBlcmNlbGwiLCJhdWQiOiJzdXBlcmNlbGw6Z2FtZWFwaSIsImp0aSI6ImRkODUyOTUwLTNmMjQtNDQ3MS05MmQyLTMwMGI3M2QzYzUwZCIsImlhdCI6MTcwMTY5OTA5NCwic3ViIjoiZGV2ZWxvcGVyLzE2MDFiZDZlLTBkMDEtOGNkMi04NGEzLTkxZjVlMzAzY2MzYiIsInNjb3BlcyI6WyJyb3lhbGUiXSwibGltaXRzIjpbeyJ0aWVyIjoiZGV2ZWxvcGVyL3NpbHZlciIsInR5cGUiOiJ0aHJvdHRsaW5nIn0seyJjaWRycyI6WyIxODUuMTQuMTc4LjE3NCJdLCJ0eXBlIjoiY2xpZW50In1dfQ.TEALPHMNo9WWJXKPjhDeNbil6EwWXHkaJzWndsbXJO5yL7WtyzN0mFCHHsbNZMoTtNOEruLVbXME4sE3iHRjkw"
    },
  });
  json = await response.json();
  console.log(json);
}
//request_async_clash()
