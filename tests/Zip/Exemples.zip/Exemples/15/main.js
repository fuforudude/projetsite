// avec let il y a un parcours :
// of : par valeurs
// in : par indices

for (let i=0 ; i<20 ; i+=3) {
  document.write(i, " ")
}
document.write('<br>') ;

let t = [10,11,12,13,14,15];
// parcours par valeurs
for(let v of t){
   document.write(v) ;
   document.write(' ');
}
document.write('<br>') ;

// parcours par indices
for(let i in t){
  document.write(i+" :" +t[i]) ;
  document.write(' ');
}
document.write('<br>') ;

// parcours par valeurs des caractères d'une String
let s = 'bonjour';
for(let c of s){
  document.write(c.toUpperCase()) ;
  document.write(' ');
}
document.write('<br>') ;

let p = {
  nom : 'Miro',
  prenom : 'Joan'
};

for(let attr in p){
  document.write( attr + ' : ' + p[attr] + '<br>') ;
}

// pas le droit de parcourir un objet par valeurs
/*for(let attr of p){
  document.write( attr +'<br>') ;
}*/

const skip = 3;
const stop = 8;
let i = 0;
while (i<10) {
   if (i === skip) {
      i++;
      continue;
   }
   if (i === stop) {
     break;
   }
   i++;
   document.write("coucou "+i+" <br/>");
}

let v = ["b","o","n","j","o","u","r"];

// foreach (approche fonctionnelle)
v.forEach(element => {
  if (element === "o" || (element === "u")) {
    document.write("*");
  }
  else  {
    document.write(element);
  }
});

document.write("<br/>et ... <br/>");

for (let i=0; i <10; i++ ) {
  document.write(i);
}
document.write("<br/>et ... <br/>");

for (let i=0 ; i < 10 ; ++i) {
  if (i === 3) {
      continue;
  }
  if (i === 5) {
      break;
  }
  document.write(i, " ")
}