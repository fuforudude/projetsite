// exemples sur les if/else
let a = 5
let c = '5'

if (a != c) {
    document.write("Ils sont différents au sens souple")
}

if (a !== c) {
    document.write("Ils sont différents au sens strict")
}

if (a > 4 && a < 6) {
    console.log("a == 5");
}
else {
    console.log("a != 5");
}

let b = (a%2 == 0)?56:45 ;
document.write("<br/>");
document.write(b);
