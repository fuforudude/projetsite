// String API
let v = new String('Bonjour') ; 
document.write(typeof v); document.write('<br>');
document.write(v.length); document.write('<br>');
document.write(v[0]); document.write('<br>');
document.write(v.indexOf('jou'));document.write('<br>');
document.write(v.slice(2,3));document.write('<br>');
document.write(v.toLowerCase());document.write('<br>');
document.write(v.toUpperCase());document.write('<br>');
document.write(v.replace('Bon', 'Beau'));document.write('<br>');
document.write(v.concat(' tout le monde'));document.write('<br>');
document.write (v === 'Bonjour');document.write('<br>');
v = 'zéro;un;deux;trois;quatre;cinq;six;sept;huit;neuf;dix';
let tab_str = v.split(';') ;
document.write(tab_str[3]); document.write('<br>');
