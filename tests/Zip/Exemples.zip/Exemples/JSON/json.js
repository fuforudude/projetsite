const s = JSON.stringify({ "nom":"Zao", "prenom":"Wou-Ki"});
document.write('{"nom":"Zao","prenom":"Wou-Ki"}') ;
document.write("<br/>");
const json = '{"nom":"Pollock", "prenom":"Jackson"}';
const obj = JSON.parse(json);
document.write(obj.nom);
document.write("<br/>");
document.write(obj.prenom);

