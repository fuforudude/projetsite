let v = 'bonjour' ; 
// Afficher le caractère * à la place des voyelles en utilisant une boucle for et l'instruction if
