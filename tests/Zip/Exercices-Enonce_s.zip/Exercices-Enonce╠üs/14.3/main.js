// Ecrire une fonction qui ajoute un noeud texte "Bonjour tout le monde" dans le noeud div d'id 'cible'
function creerBonjourTexte(texte){
  // création du noeud texte :
  const textHTML = document.createTextNode(texte) ;
  return textHTML;
}

function creerBonjourSpan(texteSpan){
  // Création d'un noeud span
  const span = document.createElement("span") ;
  // Appel de la fonction pour créer un noeud texte
  const texte = creerBonjourTexte(texteSpan);//
  // Ajout du noeud texte comme enfant du noeud span
  span.appendChild(texte);
  // On retourne le noeud span (pas encore relié à notre document)
  return span ;
}

// On récupère le noeud cible
const cible = document.querySelector("#cible") ;
// Appel de la fonction créant un noeud span 'Bonjour'
const spanBonjour = creerBonjourSpan('Bonjour') ;
// Ajout du noeud span dans le noeud cible du document :
cible.appendChild(spanBonjour);
// Créer le span avec l'espace :
const spanSpace = creerBonjourSpan(' ') ;
cible.appendChild(spanSpace);
// Créer le span avec 'tout le monde' :
const spanTout = creerBonjourSpan('tout le monde') ;
cible.appendChild(spanTout) ;
