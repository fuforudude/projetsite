//Afficher la liste suivante dans l’orde alphabétique :
// Lucian Freud, Marc Chagall, Paul Klee, Wassily Kandinsky , Francis Picabia, Pierre Soulages, Maurice Denis, Henri Matisse, Francis Bacon, Edgar Degas, René Magritte,
// Créer un tableau trié avec la liste précédente


// Afficher le tableau
