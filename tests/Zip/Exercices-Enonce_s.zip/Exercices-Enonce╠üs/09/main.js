// Ecrire une fonction lancer_de qui prend un nombre en paramètre et retourne un entier aléatoire entre 1 et le paramètre

// Puis calculer :
// Max : nombre aléatoire entre 1 et 100

// Skip : nombre aléatoire entre 1 et Max

// Ecrire les nombres entre 0 et Max sauf ceux qui sont divisibles par Skip (N%Skip == 0)

// A chaque itération de la boucle, lancer un dé à 20 faces et si le nombre est 1 arrêter la boucle
