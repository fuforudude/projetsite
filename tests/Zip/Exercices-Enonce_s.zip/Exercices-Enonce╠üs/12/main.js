// Vérfier qu'un mot est un anagrame d'un autre
function est_anagramme(mot_1, mot_2){
}


function verifierAnagramme(){
  const mot_1 = document.querySelector("#mot1").value ;
  const mot_2 = document.querySelector("#mot2").value ;
  let message = "'" + mot_1 + "' ";
  if(est_anagramme(mot_1, mot_2)){
      message +=  "est" ;
  }
  else{
      message +=  "n'est pas" ;
  }
  message +=  " un anagrame de '" + mot_2 + "'" ;
  alert(message) ;
}