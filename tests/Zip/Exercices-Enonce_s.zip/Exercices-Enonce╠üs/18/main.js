function Caracteristique(nom_, type_){
  this.nom = nom_;
  this.type = type_;
}

function Elements(){
  this.caracteristiques = new Array();
  
}
let vcard = new Elements();
vcard.caracteristiques.push(new Caracteristique('Nom','text'));
vcard.caracteristiques.push(new Caracteristique('Prénom','text'));
vcard.caracteristiques.push(new Caracteristique('email','email'));
vcard.caracteristiques.push(new Caracteristique('Téléphone','tel'));
vcard.caracteristiques.push(new Caracteristique('Abonné newsletter','checkbox'));
vcard.caracteristiques.push(new Caracteristique('Naissance','date'));


// Ecrire une (ou des) fonction qui gère le bouton 'ajouter' : 
// récupération des valeurs des input
// Création d'un nouvel item dans AnnuaireContacts avec les propriétés saisie dans le formulaire
// Remise à zéro des valeurs du formulaire

// Ecrire une (ou des) fonction qui génère un formulaire selon un paramètre de type Elements


const doc = document.querySelector('#Formulaire') ;
doc.appendChild(creerFormulaireHTML(vcard)) ;