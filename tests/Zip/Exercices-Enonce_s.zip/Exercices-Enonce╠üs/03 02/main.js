// Créer un objet adresse avec un numéro de rue, un nom de rue, un code postale et le nom d'une ville
// L'initialiser avec votre adresse et l'afficher sur la page


// Créer un objet film avec un titre, un réalisateur et une date de sortie (chaîne de caractère)
// L'initialiser avec des valeurs et l'afficher sur la page


// Créer un objet jeu avec un titre, un nom d'éditeur et un booléen pour dire qu'il est multi-joueur ou non
// L'initialiser avec des valeurs et l'afficher sur la page
