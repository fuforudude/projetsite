let v = 'bonjour' ; 
// Afficher le caractère * à la place des voyelles en utilisant une boucle while et l'instruction switch/case
