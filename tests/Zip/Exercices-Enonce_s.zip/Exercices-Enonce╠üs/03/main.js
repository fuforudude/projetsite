let v = 'bonjour' ; 
// Afficher Bonjour

// Afficher Bon jour

// Afficher Jour

// Afficher le caractère * à la place des voyelles
