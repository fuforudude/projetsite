//Afficher la liste suivante dans l’orde alphabétique :
// Lucian Freud, Marc Chagall, Paul Klee, Wassily Kandinsky , Francis Picabia, Pierre Soulages, Maurice Denis, Henri Matisse, Francis Bacon, Edgar Degas, René Magritte,
// Créer un tableau avec la liste précédente

// Trier le tableau (https://fr.wikipedia.org/wiki/Tri_rapide) par nom
// => Ecrire une fonction choix_pivot(tableau, ix_premier, ix_dernier) : la fonction choix pivot retourne un index aléatoire entre ix_premier et ix_fin
// => Ecrire une fonction "partitionner"(tableau,ix_premier, ix_dernier, ix_pivot)
// => Ecrire une fonction tri_rapide(tableau,ix_premier, ix_dernier)

// Afficher le tableau trié
