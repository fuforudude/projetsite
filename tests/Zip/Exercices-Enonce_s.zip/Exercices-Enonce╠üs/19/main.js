/*
Créer une classe Rendez-vous avec les propriétés suivantes:
Une date de rendez vous
Un objet
Un lieu
Une fonction pour calculer le temps restant en minute avant la date du rendez-vous
Une function pour afficher le rendez-vous 
*/