// Ecrire une fonction qui ajoute un noeud texte "Bonjour tout le monde" dans le noeud div d'id 'cible'
function creerBonjourTexte(texte){
  // création du noeud texte :
  const textHTML = document.createTextNode(texte) ;
  return textHTML;
}

function creerBonjourSpan(texteSpan, couleur){
  // Création d'un noeud span
  const span = document.createElement("span") ;
  // Appel de la fonction pour créer un noeud texte
  const texte = creerBonjourTexte(texteSpan);//
  // Ajout du noeud texte comme enfant du noeud span
  span.appendChild(texte);
  if(couleur){
    span.style.color = couleur ;
  }
  else{
    span.style.color = 'black';
  }
  // On retourne le noeud span (pas encore relié à notre document)
  return span ;
}

function creerDivPeintre(p){
  const div = document.createElement('div') ;
  // Appel de la fonction créant un noeud span nom
  const spanBonjour = creerBonjourSpan(p.nom, 'red') ;
  // Ajout du noeud span dans le noeud cible du document :
  div.appendChild(spanBonjour);

  // Créer le span avec l'espace :
  const spanSpace = creerBonjourSpan(' : ') ;
  div.appendChild(spanSpace);

  // Créer le span avec prenom :
  const spanTout = creerBonjourSpan(p.prenom, 'blue') ;
  div.appendChild(spanTout) ;
  
  return div ;
}

function creerLiPeintre(p){
  const li = document.createElement('li');
  li.appendChild(creerDivPeintre(p));
  return li ;
}

function creerListe(tabPeintres){
  const ul = document.createElement('ul') ;
  tabPeintres.forEach( p => ul.appendChild(creerLiPeintre(p)));
  
  return ul ;
}

const tabPeintre = [
  {nom:"Picasso", prenom : "Pablo"} 
  ,{nom:"Miro", prenom : "Joan"} 
  ];
// On récupère le noeud cible
const cible = document.querySelector("#cible") ;
cible.appendChild(creerListe(tabPeintre)) ;



