let v = 42 ;
// afficher le type de v

v = 3.14  ;
// afficher le type de v

v = "chaine";
// afficher le type de v

v = true;
// afficher le type de v

v = {prop : "valeur" };
// afficher le type de v
