let tableau = new Array(
  'fonctionnels'
  ,'performance'
  ,'personnalisation'
  ,'publicité'
);

// Créer une liste avec les éléments du tableau ci dessus
// installer un gestionnaire d'évènement pour onclick, pour onmouseover et pour onmouseout
// Comportement attendu : 
//    lorsque la souris passe par dessus un item de la liste, il prend la couleur tomato si et seulement si il n'est pas sélectionné
//    lorsque la souris n'est plus sur un item de la liste, il reprend la couleur par défaut si et seulement si il n'est pas sélectionné
//    lorsqu'on click sur un élément non sélectionné, il devient sélectionné
//    lorsqu'on click sur un élément sélectionné, il devient non sélectionné
//    un élément sélectionné est affiché de couleur yellowGreen
const ul = document.createElement('ul');
tableau.forEach( p => {
  const texte = document.createTextNode(p);
  const li = document.createElement('li'); // on pourrait sans doutes ajouter le gestionnaire d'events ici
  li.appendChild(texte);
  ul.appendChild(li);
})

const doc = document.querySelector('#cookies') ;
doc.appendChild(ul) ;

const items = document.querySelectorAll('li') ;
items.forEach( i => {   
 
  // lorsque la souris passe par dessus un item de la liste, il prend la couleur tomato si et seulement si il n'est pas sélectionné
  i.addEventListener("mouseover", (event) => {
    if (! i.classList.contains("select")) {
      i.classList.add("over")
    }
  });
  // lorsque la souris n'est plus sur un item de la liste, il reprend la couleur par défaut si et seulement si il n'est pas sélectionné
  i.addEventListener("mouseout", (event) => {
    if (! i.classList.contains("select")) {
      i.classList.remove("over")
    }
  });

 i.addEventListener("click", (event) => {
    if (i.classList.contains("select")) {
      i.classList.remove("select")
    }
    else {
      i.classList.add("select");
      i.classList.remove("over"); // A ajouter sinon cela ne fonctionne pas
    }
});
})
